//
//  main.m
//  datumDemo
//
//  Created by zhangkai on 2019/1/6.
//  Copyright © 2019年 zhangkai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
